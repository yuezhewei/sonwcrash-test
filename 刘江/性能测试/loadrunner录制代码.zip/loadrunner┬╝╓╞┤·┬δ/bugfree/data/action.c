Action()
{

	web_add_cookie("1_product=7c70d8babf6c2622289bddd2d2097c2d8906867cs%3A1%3A%221%22%3B; DOMAIN=10.7.90.245");

	web_add_cookie("pageSize=2dd7b4b260f1513a73b85b51114fb53ef3d8d056s%3A2%3A%2220%22%3B; DOMAIN=10.7.90.245");

	web_add_cookie("ac-cookie=%5B%7B%22data%22%3A%5B%22%E7%B3%BB%E7%BB%9F%E7%AE%A1%E7%90%86%E5%91%98%22%2C%22%E7%B3%BB%E7%BB%9F%E7%AE%A1%E7%90%86%E5%91%98%5Badmin%5D%22%5D%2C%22value%22%3A%22%E7%B3%BB%E7%BB%9F%E7%AE%A1%E7%90%86%E5%91%98%22%2C%22result%22%3A%22%E7%B3%BB%E7%BB%9F%E7%AE%A1%E7%90%86%E5%91%98%22%7D%5D; DOMAIN=10.7.90.245");

	web_add_cookie("c6c67eb2a96c08fad02d5e0abfb6372b=ccf78f4f8eacc35769d8e7e5f595c430d6c1a9eas%3A163%3A%22fcb1e38b50e831e8b7bae62ccdc3868a69872284a%3A4%3A%7Bi%3A0%3Bs%3A1%3A%221%22%3Bi%3A1%3Bs%3A5%3A%22admin%22%3Bi%3A2%3Bi%3A2592000%3Bi%3A3%3Ba%3A2%3A%7Bs%3A8%3A%22realname%22%3Bs%3A15%3A%22%E7%B3%BB%E7%BB%9F%E7%AE%A1%E7%90%86%E5%91%98%22%3Bs%3A8%3A%22username%22%3Bs%3A5%3A%22admin%22%3B%7D%7D%22%3B; DOMAIN=10.7.90.245");

	web_add_cookie("language=33142191c8a895b509ca2fb6f6cc597a3125f158s%3A5%3A%22zh_cn%22%3B; DOMAIN=10.7.90.245");

	web_url("login", 
		"URL=http://10.7.90.245:8032/bugfree/index.php/site/login", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bugfree/themes/classic/assets/images/blue/seperate_line.png", ENDITEM, 
		"Url=/bugfree/themes/classic/assets/images/blue/logo_login.png", ENDITEM, 
		LAST);

	web_submit_form("login_2", 
		"Snapshot=t5.inf", 
		ITEMDATA, 
		"Name=LoginForm[username]", "Value=admin", ENDITEM, 
		"Name=LoginForm[password]", "Value=admin", ENDITEM, 
		"Name=LoginForm[language]", "Value=�\x80体中�\x87", ENDITEM, 
		"Name=LoginForm[rememberMe]", "Value=1", ENDITEM, 
		EXTRARES, 
		"Url=/bugfree/themes/classic/assets/images/down.gif", "Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", ENDITEM, 
		"Url=/bugfree/themes/classic/assets/images/active.png", "Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", ENDITEM, 
		"Url=/bugfree/themes/classic/assets/images//close_div.gif", "Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", ENDITEM, 
		"Url=/bugfree/assets/65cb0d52/jui/css/base/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", ENDITEM, 
		"Url=/bugfree/assets/65cb0d52/jui/css/base/images/ui-bg_highlight-soft_75_cccccc_1x100.png", "Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", ENDITEM, 
		"Url=/bugfree/assets/65cb0d52/jui/css/base/images/ui-icons_222222_256x240.png", "Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", ENDITEM, 
		"Url=/bugfree/assets/c4a5a759/img/page.gif", "Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", ENDITEM, 
		LAST);

	web_submit_data("getProductModule", 
		"Action=http://10.7.90.245:8032/bugfree/index.php/search/getProductModule", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=product_id", "Value=1", ENDITEM, 
		"Name=productmodule_id", "Value=0", ENDITEM, 
		LAST);

	web_url("edit", 
		"URL=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/bugfree/themes/classic/assets/images/active.png", "Referer=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", ENDITEM, 
		"Url=/bugfree/assets/65cb0d52/jui/css/base/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", ENDITEM, 
		"Url=/bugfree/assets/65cb0d52/jui/css/base/images/ui-bg_highlight-soft_75_cccccc_1x100.png", "Referer=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", ENDITEM, 
		"Url=/bugfree/assets/65cb0d52/jui/css/base/images/ui-icons_222222_256x240.png", "Referer=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", ENDITEM, 
		"Url=/bugfree/assets/a2a4058f/themes/default/default.css", "Referer=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", ENDITEM, 
		"Url=/bugfree/assets/a2a4058f/themes/default/default.png", "Referer=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", ENDITEM, 
		"Url=/bugfree/assets/f94ed65d/indicator.gif", "Referer=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", ENDITEM, 
		LAST);

	lr_think_time(36);

	web_submit_data("edit_2", 
		"Action=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=http://10.7.90.245:8032/bugfree/index.php/info/edit?type=bug&action=opened&product_id=1", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=BugInfoView[deleted_file_id]", "Value=", ENDITEM, 
		"Name=BugInfoView[lock_version]", "Value=", ENDITEM, 
		"Name=BugInfoView[product_id]", "Value=1", ENDITEM, 
		"Name=isPageDirty", "Value=1", ENDITEM, 
		"Name=templateTitle", "Value=", ENDITEM, 
		"Name=BugInfoView[title]", "Value=bug_test", ENDITEM, 
		"Name=layer1_module", "Value=0", ENDITEM, 
		"Name=BugInfoView[productmodule_id]", "Value=0", ENDITEM, 
		"Name=BugInfoView[assign_to_name]", "Value=系统管理�\x98", ENDITEM, 
		"Name=BugInfoView[mail_to]", "Value=系统管理�\x98,", ENDITEM, 
		"Name=BugInfoView[severity]", "Value=1", ENDITEM, 
		"Name=BugInfoView[priority]", "Value=1", ENDITEM, 
		"Name=Custom[BugType]", "Value=代码错误", ENDITEM, 
		"Name=Custom[HowFound]", "Value=功能测试", ENDITEM, 
		"Name=Custom[BugOS]", "Value=全部", ENDITEM, 
		"Name=Custom[BugBrowser]", "Value=全部", ENDITEM, 
		"Name=Custom[OpenedBuild]", "Value=Bulid_test", ENDITEM, 
		"Name=Custom[ResolvedBuild]", "Value=", ENDITEM, 
		"Name=Custom[BugSubStatus]", "Value=Hold", ENDITEM, 
		"Name=Custom[BugMachine]", "Value=", ENDITEM, 
		"Name=Custom[BugKeyword]", "Value=", ENDITEM, 
		"Name=BugInfoView[related_bug]", "Value=", ENDITEM, 
		"Name=BugInfoView[related_case]", "Value=", ENDITEM, 
		"Name=BugInfoView[related_result]", "Value=", ENDITEM, 
		"Name=attachment_file[]", "Value=", "File=Yes", ENDITEM, 
		"Name=BugInfoView[action_note]", "Value=", ENDITEM, 
		"Name=BugInfoView[repeat_step]", "Value=[步骤]<br />\r\n1.<br />\r\n2.<br />\r\n<br />\r\n[结果]<br />\r\n<br />\r\n[期望]<br />\r\n<br />\r\n[备注]<br />\r\n<br />", ENDITEM, 
		LAST);

	web_image("BugFree", 
		"Alt=BugFree", 
		"Snapshot=t9.inf", 
		EXTRARES, 
		"Url=/bugfree/themes/classic/assets/images/down.gif", ENDITEM, 
		"Url=/bugfree/themes/classic/assets/images//close_div.gif", ENDITEM, 
		"Url=/bugfree/assets/c4a5a759/img/page.gif", ENDITEM, 
		LAST);

	web_link("bug_test", 
		"Text=bug_test", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("getPreNextId", 
		"URL=http://10.7.90.245:8032/bugfree/index.php/search/getPreNextId?id=1143&type=bug&product_id=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.7.90.245:8032/bugfree/index.php/bug/1143", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("getProductModule_2", 
		"Action=http://10.7.90.245:8032/bugfree/index.php/search/getProductModule", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://10.7.90.245:8032/bugfree/index.php/bug/list/1", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=product_id", "Value=1", ENDITEM, 
		"Name=productmodule_id", "Value=0", ENDITEM, 
		LAST);

	return 0;
}